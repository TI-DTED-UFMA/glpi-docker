
# Compatível com GLPI 9.5.x

- Antes de instalar remova qualquer versão anterior do plugin.
- Depois de descompactar o arquivo, renomeie a pasta para "mod".

#  GLPI 9.5.x compatible

- Before install remove any previous versions of plugin.
- Rename the unziped folder to "mod".
